import { Experience, Project, Skill, ContactInfo } from '../types/portfolio';

export const personalInfo = {
  name: 'MD Masud Sikdar',
  title: 'Full Stack Developer',
  tagline: 'Crafting digital experiences with modern technologies and innovative solutions',
  bio: `Passionate full-stack developer with 5+ years of experience in building scalable web applications. 
        I specialize in modern JavaScript frameworks, cloud technologies, and creating seamless user experiences. 
        My expertise spans from frontend development with React and TypeScript to backend architecture with Node.js and cloud deployment. 
        I'm committed to writing clean, maintainable code and staying current with industry best practices.`,
  yearsOfExperience: 5,
  projectsCompleted: 25,
  clientsSatisfied: 15
};

export const experiences: Experience[] = [
  {
    id: '1',
    company: 'TechCorp Solutions',
    position: 'Senior Full Stack Developer',
    duration: 'Jan 2022 - Present',
    location: 'Dhaka, Bangladesh',
    description: [
      'Led development of 3 major web applications serving 10,000+ active users with 99.9% uptime',
      'Architected and implemented scalable RESTful APIs using Node.js, Express, and PostgreSQL',
      'Optimized database queries and implemented caching strategies, resulting in 40% performance improvement',
      'Mentored 4 junior developers and established code review processes that reduced bugs by 35%',
      'Collaborated with cross-functional teams to deliver projects 20% ahead of schedule',
      'Implemented CI/CD pipelines using Docker and AWS, reducing deployment time by 60%'
    ],
    technologies: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'AWS', 'Docker', 'Redis']
  },
  {
    id: '2',
    company: 'Digital Innovation Hub',
    position: 'Frontend Developer',
    duration: 'Jun 2020 - Dec 2021',
    location: 'Dhaka, Bangladesh',
    description: [
      'Developed 8+ responsive web applications using React, TypeScript, and modern CSS frameworks',
      'Collaborated with UX/UI designers to implement pixel-perfect designs with 100% design fidelity',
      'Integrated 15+ third-party APIs including payment gateways, social media, and analytics platforms',
      'Improved application performance by 35% through code splitting, lazy loading, and optimization techniques',
      'Implemented comprehensive testing strategies using Jest and React Testing Library',
      'Participated in agile development processes and contributed to sprint planning and retrospectives'
    ],
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Redux', 'Jest', 'Webpack', 'Sass']
  },
  {
    id: '3',
    company: 'StartupXYZ',
    position: 'Junior Web Developer',
    duration: 'Jan 2019 - May 2020',
    location: 'Dhaka, Bangladesh',
    description: [
      'Built and maintained 5+ company websites using WordPress, custom PHP, and modern JavaScript',
      'Implemented responsive designs ensuring cross-browser compatibility across all major browsers',
      'Designed and optimized MySQL databases, improving query performance by 25%',
      'Collaborated in agile development processes and participated in daily standups and sprint reviews',
      'Created custom WordPress themes and plugins to meet specific business requirements',
      'Provided technical support and training to non-technical team members'
    ],
    technologies: ['PHP', 'WordPress', 'MySQL', 'JavaScript', 'Bootstrap', 'jQuery']
  }
];

export const projects: Project[] = [
  {
    id: '1',
    title: 'E-Commerce Platform',
    description: 'A comprehensive e-commerce solution with advanced features including real-time inventory management, multi-vendor support, and integrated analytics dashboard.',
    technologies: ['React', 'Node.js', 'MongoDB', 'Stripe', 'AWS', 'Redis', 'Socket.io'],
    features: [
      'Multi-vendor marketplace with vendor dashboard',
      'Real-time inventory management and notifications',
      'Advanced product search with filters and sorting',
      'Secure payment processing with multiple gateways',
      'Order tracking and automated email notifications',
      'Analytics dashboard with sales insights',
      'Mobile-responsive design with PWA features',
      'Admin panel with comprehensive reporting'
    ],
    githubUrl: 'https://github.com/mmasud',
    liveUrl: 'https://ecommerce-demo.com'
  },
  {
    id: '2',
    title: 'Task Management App',
    description: 'A collaborative project management platform with real-time updates, team collaboration features, and advanced project tracking capabilities.',
    technologies: ['React', 'TypeScript', 'Socket.io', 'Express', 'PostgreSQL', 'Docker'],
    features: [
      'Real-time collaboration with live updates',
      'Kanban boards with drag-and-drop functionality',
      'Team member management and role-based permissions',
      'File attachments with cloud storage integration',
      'Time tracking and productivity analytics',
      'Custom project templates and workflows',
      'Mobile app with offline synchronization',
      'Integration with popular tools (Slack, GitHub)'
    ],
    githubUrl: 'https://github.com/mmasud'
  },
  {
    id: '3',
    title: 'Weather Analytics Dashboard',
    description: 'An advanced weather monitoring system with predictive analytics, historical data visualization, and location-based weather insights.',
    technologies: ['React', 'D3.js', 'Node.js', 'OpenWeather API', 'Chart.js', 'Tailwind CSS'],
    features: [
      'Real-time weather data from multiple sources',
      'Interactive weather maps with layers',
      '15-day weather forecasts with accuracy metrics',
      'Historical weather data analysis and trends',
      'Custom weather alerts and notifications',
      'Air quality monitoring and health recommendations',
      'Weather-based activity suggestions',
      'Export data in multiple formats (CSV, PDF, JSON)'
    ],
    githubUrl: 'https://github.com/mmasud',
    liveUrl: 'https://weather-dashboard-demo.com'
  },
  {
    id: '4',
    title: 'Content Management System',
    description: 'A modern, headless CMS with advanced content editing capabilities, multi-language support, and powerful API for content delivery.',
    technologies: ['Next.js', 'Prisma', 'PostgreSQL', 'NextAuth.js', 'Cloudinary', 'Vercel'],
    features: [
      'Headless architecture with RESTful and GraphQL APIs',
      'Rich text editor with media management',
      'Multi-language content support',
      'Role-based access control and permissions',
      'SEO optimization tools and meta management',
      'Content versioning and revision history',
      'Automated content publishing and scheduling',
      'Analytics integration and performance monitoring'
    ],
    githubUrl: 'https://github.com/mmasud'
  }
];

export const skills: Skill[] = [
  // Frontend
  { name: 'React', category: 'frontend' },
  { name: 'TypeScript', category: 'frontend' },
  { name: 'JavaScript (ES6+)', category: 'frontend' },
  { name: 'Next.js', category: 'frontend' },
  { name: 'Vue.js', category: 'frontend' },
  { name: 'Tailwind CSS', category: 'frontend' },
  { name: 'Sass/SCSS', category: 'frontend' },
  { name: 'HTML5 & CSS3', category: 'frontend' },
  { name: 'Responsive Design', category: 'frontend' },
  { name: 'Progressive Web Apps', category: 'frontend' },
  
  // Backend
  { name: 'Node.js', category: 'backend' },
  { name: 'Express.js', category: 'backend' },
  { name: 'Python', category: 'backend' },
  { name: 'Django', category: 'backend' },
  { name: 'PHP', category: 'backend' },
  { name: 'RESTful APIs', category: 'backend' },
  { name: 'GraphQL', category: 'backend' },
  { name: 'Microservices', category: 'backend' },
  
  // Database
  { name: 'PostgreSQL', category: 'database' },
  { name: 'MongoDB', category: 'database' },
  { name: 'MySQL', category: 'database' },
  { name: 'Redis', category: 'database' },
  { name: 'Prisma ORM', category: 'database' },
  { name: 'Database Design', category: 'database' },
  
  // Mobile
  { name: 'React Native', category: 'mobile' },
  { name: 'Flutter', category: 'mobile' },
  { name: 'Mobile-First Design', category: 'mobile' },
  
  // Cloud & DevOps
  { name: 'AWS', category: 'cloud' },
  { name: 'Docker', category: 'cloud' },
  { name: 'Kubernetes', category: 'cloud' },
  { name: 'CI/CD Pipelines', category: 'cloud' },
  { name: 'Vercel', category: 'cloud' },
  { name: 'Netlify', category: 'cloud' },
  
  // Security & Testing
  { name: 'Jest', category: 'security' },
  { name: 'Cypress', category: 'security' },
  { name: 'Unit Testing', category: 'security' },
  { name: 'Integration Testing', category: 'security' },
  { name: 'Security Best Practices', category: 'security' },
  
  // Tools
  { name: 'Git & GitHub', category: 'tools' },
  { name: 'VS Code', category: 'tools' },
  { name: 'Figma', category: 'tools' },
  { name: 'Postman', category: 'tools' },
  { name: 'Webpack', category: 'tools' },
  { name: 'Vite', category: 'tools' },
  { name: 'ESLint & Prettier', category: 'tools' }
];

export const contactInfo: ContactInfo = {
  email: 'masud.sikdar@example.com',
  phone: '+880 1234 567890',
  location: 'Dhaka, Bangladesh',
  linkedin: 'https://linkedin.com/in/md-masud-sikdar',
  github: 'https://github.com/mmasud'
};