import React, { useState } from 'react';
import { MapPin, Calendar, Building, ChevronRight, Award, TrendingUp, Briefcase, Clock, Star, Zap, Target, Sparkles, Trophy, Rocket, Code, Terminal, GitBranch, Database, Server } from 'lucide-react';
import { experiences } from '../data/portfolioData';

const Experience: React.FC = () => {
  const [selectedExperience, setSelectedExperience] = useState<string>(experiences[0]?.id || '');

  const getExperienceLevel = (position: string) => {
    if (position.toLowerCase().includes('senior')) return { 
      level: 'Senior', 
      color: 'from-purple-500 to-indigo-500', 
      textColor: 'text-purple-600',
      icon: Trophy,
      bgColor: 'bg-purple-100',
      codeSymbol: '{ senior }',
      pattern: 'senior-dev'
    };
    if (position.toLowerCase().includes('lead')) return { 
      level: 'Lead', 
      color: 'from-blue-500 to-cyan-500', 
      textColor: 'text-blue-600',
      icon: Rocket,
      bgColor: 'bg-blue-100',
      codeSymbol: '< lead />',
      pattern: 'tech-lead'
    };
    if (position.toLowerCase().includes('junior')) return { 
      level: 'Junior', 
      color: 'from-green-500 to-emerald-500', 
      textColor: 'text-green-600',
      icon: Star,
      bgColor: 'bg-green-100',
      codeSymbol: 'junior()',
      pattern: 'junior-dev'
    };
    return { 
      level: 'Mid', 
      color: 'from-orange-500 to-amber-500', 
      textColor: 'text-orange-600',
      icon: Award,
      bgColor: 'bg-orange-100',
      codeSymbol: '[mid-level]',
      pattern: 'mid-dev'
    };
  };

  const selectedExp = experiences.find(exp => exp.id === selectedExperience) || experiences[0];
  const levelInfo = getExperienceLevel(selectedExp.position);

  return (
    <section id="experience" className="py-16 bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 text-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%2210%22 y=%2220%22 font-family=%22monospace%22 font-size=%226%22%3Eexp%3C/text%3E%3Ctext x=%2230%22 y=%2240%22 font-family=%22monospace%22 font-size=%226%22%3Edev%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat animate-pulse"></div>
      </div>

      {/* Floating Code Elements */}
      <div className="absolute top-20 left-10 text-green-400/20 font-mono text-lg animate-float">const experience = {}</div>
      <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-sm animate-bounce">function career() {}</div>
      <div className="absolute bottom-40 left-20 text-purple-400/20 font-mono text-base animate-pulse">// professional journey</div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full mb-6">
            <Terminal className="w-4 h-4 text-green-400 mr-2" />
            <span className="text-green-300 font-mono text-sm">./career --timeline</span>
            <Sparkles className="w-4 h-4 text-green-400 ml-2" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white/90">Professional</span>
            <br />
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent font-mono">
              &lt;Experience /&gt;
            </span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto font-mono">
            // A journey of growth, innovation, and technical excellence
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Creative Code-Style Timeline */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden sticky top-8">
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
                <div className="flex items-center space-x-3">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Terminal className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 text-sm font-mono">career-timeline.js</span>
                </div>
                <div className="flex items-center space-x-2">
                  <GitBranch className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-gray-400">main</span>
                </div>
              </div>
              
              <div className="p-6 font-mono text-sm">
                <div className="text-gray-500 text-xs mb-4">// Career progression timeline</div>
                
                <div className="space-y-4">
                  {experiences.map((exp, index) => {
                    const isSelected = selectedExperience === exp.id;
                    const levelInfo = getExperienceLevel(exp.position);
                    const LevelIcon = levelInfo.icon;
                    
                    return (
                      <div key={exp.id} className="relative">
                        {/* Timeline Connector */}
                        {index < experiences.length - 1 && (
                          <div className="absolute left-6 top-16 w-0.5 h-8 bg-gradient-to-b from-green-400/50 to-blue-400/50"></div>
                        )}
                        
                        <button
                          onClick={() => setSelectedExperience(exp.id)}
                          className={`w-full p-4 rounded-xl text-left transition-all duration-300 group border ${
                            isSelected 
                              ? `bg-gradient-to-r ${levelInfo.color} text-white shadow-lg border-transparent` 
                              : 'bg-gray-800/50 hover:bg-gray-700/50 border-gray-600/50 hover:border-gray-500/50 text-gray-300'
                          }`}
                        >
                          <div className="flex items-start">
                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 transition-all duration-300 ${
                              isSelected 
                                ? 'bg-white/20 backdrop-blur-sm' 
                                : 'bg-gray-700/50 group-hover:bg-gray-600/50'
                            }`}>
                              <LevelIcon className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-gray-400'}`} />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center mb-2">
                                <span className={`text-xs ${isSelected ? 'text-white/70' : 'text-green-400'}`}>
                                  {index + 1}.
                                </span>
                                <span className={`ml-2 font-bold text-sm ${isSelected ? 'text-white' : 'text-gray-200'}`}>
                                  {exp.company}
                                </span>
                              </div>
                              
                              <div className={`text-xs mb-2 font-mono ${isSelected ? 'text-white/90' : 'text-gray-400'}`}>
                                {levelInfo.codeSymbol}
                              </div>
                              
                              <div className={`text-xs ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                                {exp.duration}
                              </div>
                            </div>
                            
                            <div className="flex flex-col items-end">
                              <ChevronRight className={`w-4 h-4 transition-all ${
                                isSelected ? 'text-white rotate-90' : 'text-gray-500 group-hover:text-gray-400'
                              }`} />
                              <div className={`text-xs mt-2 px-2 py-1 rounded ${
                                isSelected ? 'bg-white/20 text-white' : 'bg-gray-700 text-gray-400'
                              }`}>
                                {levelInfo.level}
                              </div>
                            </div>
                          </div>
                        </button>
                      </div>
                    );
                  })}
                </div>

                {/* Code Footer */}
                <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700/50">
                  <div className="text-green-400 text-xs mb-2">// Output:</div>
                  <div className="text-gray-300 text-xs">
                    <div>✅ {experiences.length} companies</div>
                    <div>🚀 {experiences.reduce((total, exp) => total + exp.description.length, 0)} achievements</div>
                    <div>⚡ {Array.from(new Set(experiences.flatMap(exp => exp.technologies))).length} technologies</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Experience Details - Code Editor Style */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
              {/* Code Editor Header */}
              <div className={`h-20 bg-gradient-to-r ${levelInfo.color} relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                
                <div className="relative p-4 h-full flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mr-4">
                      <levelInfo.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white font-mono">{selectedExp.position}</h3>
                      <div className="text-white/80 text-sm font-mono">{selectedExp.company}</div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-white/90 text-sm font-mono">{selectedExp.duration}</div>
                    <div className="text-white/70 text-xs font-mono">{selectedExp.location}</div>
                  </div>
                </div>
              </div>

              {/* Code Content */}
              <div className="p-6 bg-gray-900/50 font-mono text-sm">
                {/* Function Declaration */}
                <div className="mb-6">
                  <div className="text-blue-400 mb-2">
                    <span className="text-purple-400">const</span> experience = {'{'}
                  </div>
                  <div className="ml-4 space-y-1 text-gray-300">
                    <div><span className="text-green-400">company</span>: <span className="text-yellow-300">"{selectedExp.company}"</span>,</div>
                    <div><span className="text-green-400">position</span>: <span className="text-yellow-300">"{selectedExp.position}"</span>,</div>
                    <div><span className="text-green-400">duration</span>: <span className="text-yellow-300">"{selectedExp.duration}"</span>,</div>
                    <div><span className="text-green-400">location</span>: <span className="text-yellow-300">"{selectedExp.location}"</span></div>
                  </div>
                  <div className="text-blue-400">{'};'}</div>
                </div>

                {/* Achievements Array */}
                <div className="mb-6">
                  <div className="text-blue-400 mb-2">
                    <span className="text-purple-400">const</span> achievements = [
                  </div>
                  <div className="ml-4 space-y-2">
                    {selectedExp.description.slice(0, 4).map((achievement, idx) => (
                      <div key={idx} className="flex items-start">
                        <span className="text-gray-500 mr-2">{idx + 1}.</span>
                        <span className="text-yellow-300 text-xs leading-relaxed">"{achievement}"</span>
                        {idx < selectedExp.description.length - 1 && <span className="text-gray-400">,</span>}
                      </div>
                    ))}
                  </div>
                  <div className="text-blue-400">];</div>
                </div>

                {/* Technologies Array */}
                <div className="mb-6">
                  <div className="text-blue-400 mb-2">
                    <span className="text-purple-400">const</span> technologies = [
                  </div>
                  <div className="ml-4 flex flex-wrap gap-2">
                    {selectedExp.technologies.map((tech, idx) => (
                      <span key={idx} className="text-yellow-300 text-xs">
                        "{tech}"{idx < selectedExp.technologies.length - 1 ? ',' : ''}
                      </span>
                    ))}
                  </div>
                  <div className="text-blue-400">];</div>
                </div>

                {/* Stats Object */}
                <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700/50">
                  <div className="text-green-400 text-xs mb-2">// Performance metrics</div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-lg font-bold text-white">{selectedExp.description.length}</div>
                      <div className="text-xs text-gray-400">Achievements</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-white">{selectedExp.technologies.length}</div>
                      <div className="text-xs text-gray-400">Technologies</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-white">{levelInfo.level}</div>
                      <div className="text-xs text-gray-400">Level</div>
                    </div>
                  </div>
                </div>

                {/* Console Output */}
                <div className="mt-4 p-3 bg-green-900/20 rounded-lg border border-green-500/20">
                  <div className="text-green-400 text-xs mb-1">// Console output:</div>
                  <div className="text-green-300 text-xs">
                    ✅ Experience loaded successfully!
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default Experience;