import React, { useState } from 'react';
import { ExternalLink, Github, Code, Star, Calendar, Users, ChevronDown, Filter, Search, Rocket, Zap, Terminal, GitBranch, Sparkles } from 'lucide-react';
import { projects } from '../data/portfolioData';

const Projects: React.FC = () => {
  const [visibleProjects, setVisibleProjects] = useState(3);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTech, setSelectedTech] = useState<string | null>(null);

  // Get all unique technologies
  const allTechnologies = Array.from(
    new Set(projects.flatMap(project => project.technologies))
  ).sort();

  // Filter projects based on search and technology
  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTech = !selectedTech || project.technologies.includes(selectedTech);
    return matchesSearch && matchesTech;
  });

  const loadMore = () => {
    setVisibleProjects(prev => Math.min(prev + 3, filteredProjects.length));
  };

  const getProjectIcon = (index: number) => {
    const icons = ['🚀', '⚡', '🎯', '💎', '🔥', '✨'];
    return icons[index % icons.length];
  };

  return (
    <section id="projects" className="py-16 bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 text-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%2210%22 y=%2220%22 font-family=%22monospace%22 font-size=%226%22%3Eproj%3C/text%3E%3Ctext x=%2230%22 y=%2240%22 font-family=%22monospace%22 font-size=%226%22%3Ecode%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat animate-pulse"></div>
      </div>

      {/* Floating Code Elements */}
      <div className="absolute top-20 left-10 text-green-400/20 font-mono text-lg animate-float">const projects = []</div>
      <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-sm animate-bounce">git commit -m "new project"</div>
      <div className="absolute bottom-40 left-20 text-purple-400/20 font-mono text-base animate-pulse">// portfolio showcase</div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full mb-6">
            <Terminal className="w-4 h-4 text-green-400 mr-2" />
            <span className="text-green-300 font-mono text-sm">./projects --showcase</span>
            <Sparkles className="w-4 h-4 text-green-400 ml-2" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-white/90">Featured</span>
            <br />
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent font-mono">
              {'<Projects />'}
            </span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto font-mono">
            // Innovative solutions built with modern tech stack
          </p>
        </div>

        {/* Terminal-Style Filters */}
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden mb-8">
          {/* Terminal Header */}
          <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
            <div className="flex items-center space-x-3">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              </div>
              <Terminal className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400 text-sm font-mono">project-filter.js</span>
            </div>
            <div className="flex items-center space-x-2">
              <GitBranch className="w-4 h-4 text-green-400" />
              <span className="text-xs text-gray-400">main</span>
            </div>
          </div>

          <div className="p-6">
            <div className="text-gray-500 text-xs mb-4 font-mono">// Filter and search projects</div>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <label className="block text-sm font-mono text-gray-300 mb-2">searchQuery: string</label>
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="'Search projects...'"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                />
              </div>
              
              <div className="relative">
                <label className="block text-sm font-mono text-gray-300 mb-2">filterBy: tech</label>
                <select
                  value={selectedTech || ''}
                  onChange={(e) => setSelectedTech(e.target.value || null)}
                  className="appearance-none bg-gray-700/50 border border-gray-600/50 rounded-lg px-4 py-3 pr-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                >
                  <option value="">All Technologies</option>
                  {allTechnologies.map(tech => (
                    <option key={tech} value={tech}>{tech}</option>
                  ))}
                </select>
                <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Projects Grid - Terminal Style */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.slice(0, visibleProjects).map((project, index) => (
            <div
              key={project.id}
              className="group bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden hover:border-gray-600/50 hover:-translate-y-1 transition-all duration-300"
            >
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
                <div className="flex items-center space-x-3">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Terminal className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 text-sm font-mono">{project.title.toLowerCase().replace(/\s+/g, '-')}.js</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="w-4 h-4 text-yellow-400" />
                  <span className="text-xs text-gray-400">featured</span>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6 font-mono">
                <div className="text-gray-500 text-xs mb-4">// Project: {project.title}</div>
                
                <div className="mb-4">
                  <div className="text-blue-400 mb-2">
                    <span className="text-purple-400">const</span> project = {'{'}
                  </div>
                  <div className="ml-4 space-y-1 text-gray-300 text-sm">
                    <div><span className="text-green-400">title</span>: <span className="text-yellow-300">"{project.title}"</span>,</div>
                    <div><span className="text-green-400">status</span>: <span className="text-yellow-300">"production"</span>,</div>
                    <div><span className="text-green-400">type</span>: <span className="text-yellow-300">"full-stack"</span></div>
                  </div>
                  <div className="text-blue-400">{'};'}</div>
                </div>

                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  <span className="text-gray-500">// Description:</span><br />
                  {project.description}
                </p>

                {/* Key Features - Code Style */}
                <div className="mb-4">
                  <div className="text-blue-400 text-sm mb-2">
                    <span className="text-purple-400">const</span> features = [
                  </div>
                  <div className="ml-4 space-y-1">
                    {project.features.slice(0, 3).map((feature, idx) => (
                      <div key={idx} className="text-xs text-gray-400">
                        <span className="text-gray-500">{idx + 1}.</span> <span className="text-yellow-300">"{feature}"</span>
                        {idx < Math.min(project.features.length, 3) - 1 && <span className="text-gray-400">,</span>}
                      </div>
                    ))}
                    {project.features.length > 3 && (
                      <div className="text-xs text-gray-500">// +{project.features.length - 3} more features</div>
                    )}
                  </div>
                  <div className="text-blue-400 text-sm">];</div>
                </div>

                {/* Technologies - Code Style */}
                <div className="mb-6">
                  <div className="text-blue-400 text-sm mb-2">
                    <span className="text-purple-400">const</span> techStack = [
                  </div>
                  <div className="ml-4 flex flex-wrap gap-1">
                    {project.technologies.slice(0, 4).map((tech, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-gray-700/50 text-green-300 rounded text-xs border border-gray-600/50"
                      >
                        "{tech}"{idx < Math.min(project.technologies.length, 4) - 1 ? ',' : ''}
                      </span>
                    ))}
                    {project.technologies.length > 4 && (
                      <span className="px-2 py-1 bg-gray-700/50 text-gray-400 rounded text-xs border border-gray-600/50">
                        +{project.technologies.length - 4}
                      </span>
                    )}
                  </div>
                  <div className="text-blue-400 text-sm mt-2">];</div>
                </div>

                {/* Action Buttons - Fixed at Bottom */}
                <div className="flex gap-2">
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center px-3 py-2 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-mono rounded-lg transition-all duration-300 text-sm hover:scale-105 border border-green-400/30"
                    >
                      <ExternalLink className="w-4 h-4 mr-1" />
                      live()
                    </a>
                  )}
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center px-3 py-2 bg-gray-700/50 hover:bg-gray-600/50 text-white font-mono rounded-lg transition-all duration-300 text-sm hover:scale-105 border border-gray-600/50"
                    >
                      <Github className="w-4 h-4 mr-1" />
                      code()
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Button */}
        {visibleProjects < filteredProjects.length && (
          <div className="text-center mt-8">
            <button
              onClick={loadMore}
              className="group inline-flex items-center px-6 py-3 bg-gray-800/50 hover:bg-gray-700/50 text-white font-mono rounded-xl transition-all duration-300 hover:scale-105 border border-gray-600/50 hover:border-gray-500/50"
            >
              <ChevronDown className="w-5 h-5 mr-2 group-hover:translate-y-1 transition-transform" />
              loadMore() // {filteredProjects.length - visibleProjects} remaining
            </button>
          </div>
        )}

        {/* No Results */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-12 bg-gray-800/50 rounded-2xl border border-gray-700/50">
            <div className="text-gray-400 text-lg mb-4 font-mono">// No projects found</div>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedTech(null);
              }}
              className="text-green-400 hover:text-green-300 font-mono transition-colors"
            >
              clearFilters()
            </button>
          </div>
        )}

        {/* Project Stats - Terminal Style */}
        <div className="mt-12 bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
          <div className="p-6">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-white mb-2 font-mono">
                {'// Project Statistics'}
              </h3>
              <p className="text-gray-400 font-mono text-sm">Portfolio performance metrics</p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-500/20 border border-blue-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Rocket className="w-6 h-6 text-blue-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">{projects.length}</div>
                <div className="text-sm text-gray-400 font-mono">totalProjects</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-green-500/20 border border-green-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">{allTechnologies.length}</div>
                <div className="text-sm text-gray-400 font-mono">technologies</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-500/20 border border-purple-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-purple-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">100%</div>
                <div className="text-sm text-gray-400 font-mono">successRate</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-500/20 border border-orange-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-orange-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">15+</div>
                <div className="text-sm text-gray-400 font-mono">happyClients</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default Projects;