import React, { useState, useEffect } from 'react';
import { Menu, X, Home, User, Briefcase, Code, Mail, Zap, Terminal, GitBranch, Monitor, Database, Server, Cpu } from 'lucide-react';

const Navigation: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrolled, setScrolled] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: Home, code: 'home()', color: 'text-green-400' },
    { id: 'experience', label: 'Experience', icon: Briefcase, code: 'experience[]', color: 'text-blue-400' },
    { id: 'projects', label: 'Projects', icon: Code, code: 'projects{}', color: 'text-purple-400' },
    { id: 'skills', label: 'Skills', icon: Zap, code: 'skills.map()', color: 'text-yellow-400' },
    { id: 'contact', label: 'Contact', icon: Mail, code: 'contact()', color: 'text-cyan-400' }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setScrolled(scrollPosition > 50);

      // Update active section
      const sections = navItems.map(item => document.getElementById(item.id));
      const currentSection = sections.find((section, index) => {
        if (!section) return false;
        const rect = section.getBoundingClientRect();
        return rect.top <= 100 && rect.bottom >= 100;
      });

      if (currentSection) {
        const sectionId = currentSection.id;
        setActiveSection(sectionId);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  return (
    <>
      {/* Desktop Navigation - Software Engineer Theme */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-gray-900/95 backdrop-blur-md shadow-2xl border-b border-gray-700/50' 
          : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo - Software Engineer Style */}
            <div className="flex items-center">
              <div className={`font-bold text-xl transition-colors font-mono ${
                scrolled ? 'text-white' : 'text-white'
              }`}>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-400 rounded-lg flex items-center justify-center">
                    <Terminal className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-green-400 text-lg">{'<'}</span>
                  <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                    MD Masud
                  </span>
                  <span className="text-green-400 text-lg">{'/>'}</span>
                </div>
              </div>
            </div>

            {/* Desktop Navigation - Advanced Code Style */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`group relative px-4 py-2 rounded-lg text-sm font-mono transition-all duration-300 flex items-center border ${
                    activeSection === item.id
                      ? `${item.color} bg-gray-800/50 border-gray-600/50 shadow-lg`
                      : 'text-gray-300 hover:text-green-400 hover:bg-gray-800/30 border-transparent hover:border-gray-700/50'
                  }`}
                >
                  <item.icon className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                  <span className="hidden lg:block">{item.label}</span>
                  <span className="lg:hidden text-xs">{item.code}</span>
                  
                  {/* Active Indicator */}
                  {activeSection === item.id && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-400 rounded-full animate-pulse"></div>
                  )}

                  {/* Hover Tooltip */}
                  <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                    <div className="bg-gray-900 text-green-400 px-2 py-1 rounded text-xs font-mono whitespace-nowrap border border-gray-700">
                      {item.code}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-lg text-gray-300 hover:text-green-400 hover:bg-gray-800/30 transition-colors border border-gray-700/50"
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation - Terminal Style */}
        {isOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-gray-900/95 backdrop-blur-md border-b border-gray-700/50 shadow-2xl">
            <div className="px-4 py-4 space-y-2">
              <div className="text-gray-500 text-xs mb-3 font-mono">// Navigation menu</div>
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full flex items-center px-4 py-3 text-left font-mono rounded-lg transition-all duration-200 border ${
                    activeSection === item.id
                      ? `${item.color} bg-gray-800/50 border-gray-600/50`
                      : 'text-gray-300 hover:text-green-400 hover:bg-gray-800/30 border-transparent hover:border-gray-700/50'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  <span className="flex-1">{item.label}</span>
                  <span className="text-xs text-gray-500">{item.code}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Advanced Floating Navigation - IDE Style */}
      <div className="fixed right-8 top-1/2 transform -translate-y-1/2 z-40 hidden lg:block">
        <div className="bg-gray-900/95 backdrop-blur-md rounded-2xl p-4 border border-gray-700/50 shadow-2xl">
          {/* Mini Terminal Header */}
          <div className="flex items-center justify-center mb-3 pb-2 border-b border-gray-700/50">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            </div>
          </div>

          <div className="space-y-3">
            {navItems.map((item, index) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`group relative w-4 h-4 rounded-full transition-all duration-300 border-2 ${
                  activeSection === item.id
                    ? `${item.color.replace('text-', 'bg-')} border-white scale-125 shadow-lg`
                    : 'bg-gray-600 border-gray-500 hover:bg-gray-500 hover:scale-110'
                }`}
                title={item.label}
              >
                {/* Advanced Tooltip */}
                <div className="absolute right-8 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                  <div className="bg-gray-800 text-green-400 px-3 py-2 rounded-lg text-sm font-mono whitespace-nowrap border border-gray-700/50 shadow-lg">
                    <div className="flex items-center space-x-2">
                      <item.icon className="w-4 h-4" />
                      <span>{item.code}</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1">{item.label}</div>
                  </div>
                </div>

                {/* Line Number */}
                <div className="absolute -left-6 top-1/2 transform -translate-y-1/2 text-xs text-gray-500 font-mono">
                  {String(index + 1).padStart(2, '0')}
                </div>
              </button>
            ))}
          </div>
          
          {/* System Status */}
          <div className="mt-4 pt-3 border-t border-gray-700/50">
            <div className="flex items-center justify-center space-x-2">
              <GitBranch className="w-3 h-3 text-green-400" />
              <span className="text-xs text-gray-400 font-mono">main</span>
            </div>
            <div className="flex items-center justify-center mt-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-1"></div>
              <span className="text-xs text-gray-500 font-mono">online</span>
            </div>
          </div>
        </div>
      </div>

      {/* System Status Bar - Bottom */}
      <div className="fixed bottom-4 left-4 z-40 hidden lg:block">
        <div className="bg-gray-900/95 backdrop-blur-md rounded-lg px-3 py-2 border border-gray-700/50 shadow-lg">
          <div className="flex items-center space-x-4 text-xs font-mono">
            <div className="flex items-center space-x-1">
              <Monitor className="w-3 h-3 text-blue-400" />
              <span className="text-gray-400">React</span>
            </div>
            <div className="flex items-center space-x-1">
              <Database className="w-3 h-3 text-green-400" />
              <span className="text-gray-400">TS</span>
            </div>
            <div className="flex items-center space-x-1">
              <Server className="w-3 h-3 text-purple-400" />
              <span className="text-gray-400">Node</span>
            </div>
            <div className="flex items-center space-x-1">
              <Cpu className="w-3 h-3 text-yellow-400" />
              <span className="text-gray-400">99.9%</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navigation;