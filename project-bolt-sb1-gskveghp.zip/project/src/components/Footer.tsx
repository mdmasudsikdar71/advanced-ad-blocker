import React from 'react';
import { Heart, Github, Linkedin, Mail, Code, Terminal, GitBranch, Coffee, Zap } from 'lucide-react';
import { personalInfo, contactInfo } from '../data/portfolioData';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Github, href: contactInfo.github, label: 'GitHub', code: 'github.com' },
    { icon: Linkedin, href: contactInfo.linkedin, label: 'LinkedIn', code: 'linkedin.in' },
    { icon: Mail, href: `mailto:${contactInfo.email}`, label: 'Email', code: 'sendMail()' }
  ];

  const quickStats = [
    { label: 'uptime', value: '99.9%', color: 'text-green-400' },
    { label: 'commits', value: '1.2k+', color: 'text-blue-400' },
    { label: 'coffee', value: '∞', color: 'text-yellow-400' }
  ];

  return (
    <footer className="bg-gray-900 border-t border-gray-800 relative overflow-hidden">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2240%22 height=%2240%22 viewBox=%220 0 40 40%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%225%22 y=%2215%22 font-family=%22monospace%22 font-size=%224%22%3E&lt;/&gt;%3C/text%3E%3Ctext x=%2220%22 y=%2230%22 font-family=%22monospace%22 font-size=%224%22%3E{}%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat"></div>
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Terminal-Style Footer */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-gray-700/50 overflow-hidden">
          {/* Terminal Header */}
          <div className="flex items-center justify-between px-6 py-3 bg-gray-900/50 border-b border-gray-700/50">
            <div className="flex items-center space-x-3">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
              <Terminal className="w-3 h-3 text-gray-400" />
              <span className="text-gray-400 text-xs font-mono">footer.js</span>
            </div>
            <div className="flex items-center space-x-2">
              <GitBranch className="w-3 h-3 text-green-400" />
              <span className="text-xs text-gray-400">main</span>
            </div>
          </div>

          {/* Footer Content */}
          <div className="p-6 font-mono text-sm">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* Developer Info */}
              <div>
                <div className="text-gray-500 text-xs mb-3">// Developer profile</div>
                <div className="text-blue-400 mb-2">
                  <span className="text-purple-400">const</span> developer = {'{'}
                </div>
                <div className="ml-4 space-y-1 text-gray-300">
                  <div><span className="text-green-400">name</span>: <span className="text-yellow-300">"{personalInfo.name}"</span>,</div>
                  <div><span className="text-green-400">role</span>: <span className="text-yellow-300">"Full Stack Developer"</span>,</div>
                  <div><span className="text-green-400">location</span>: <span className="text-yellow-300">"{contactInfo.location}"</span>,</div>
                  <div><span className="text-green-400">status</span>: <span className="text-yellow-300">"available"</span></div>
                </div>
                <div className="text-blue-400">{'};'}</div>
              </div>

              {/* Social Links */}
              <div>
                <div className="text-gray-500 text-xs mb-3">// Social connections</div>
                <div className="text-blue-400 mb-2">
                  <span className="text-purple-400">const</span> socialLinks = [
                </div>
                <div className="ml-4 space-y-2">
                  {socialLinks.map((social, index) => (
                    <a
                      key={social.label}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center text-gray-400 hover:text-green-400 transition-colors"
                    >
                      <social.icon className="w-4 h-4 mr-3 group-hover:scale-110 transition-transform" />
                      <span className="text-yellow-300">"{social.code}"</span>
                      <span className="text-gray-500 ml-1">,</span>
                    </a>
                  ))}
                </div>
                <div className="text-blue-400 mt-2">];</div>
              </div>

              {/* Quick Stats */}
              <div>
                <div className="text-gray-500 text-xs mb-3">// System status</div>
                <div className="text-blue-400 mb-2">
                  <span className="text-purple-400">const</span> stats = {'{'}
                </div>
                <div className="ml-4 space-y-1">
                  {quickStats.map((stat, index) => (
                    <div key={stat.label} className="flex items-center justify-between">
                      <span className="text-green-400">{stat.label}:</span>
                      <span className={`${stat.color} font-bold`}>"{stat.value}"</span>
                      {index < quickStats.length - 1 && <span className="text-gray-500">,</span>}
                    </div>
                  ))}
                </div>
                <div className="text-blue-400 mt-2">{'};'}</div>

                {/* Live Status Indicator */}
                <div className="mt-4 p-3 bg-green-900/20 rounded-lg border border-green-500/20">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                    <span className="text-green-300 text-xs">System online</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Section */}
            <div className="mt-8 pt-6 border-t border-gray-700/50">
              <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                
                {/* Copyright */}
                <div className="flex items-center text-gray-400 text-xs">
                  <span className="text-gray-500">// </span>
                  <span>Made with </span>
                  <Heart className="w-3 h-3 text-red-400 mx-1" />
                  <span>and </span>
                  <Coffee className="w-3 h-3 text-yellow-400 mx-1" />
                  <span>© {currentYear} {personalInfo.name}</span>
                </div>

                {/* Tech Stack Badge */}
                <div className="flex items-center space-x-2 text-xs">
                  <div className="flex items-center px-3 py-1 bg-gray-700/50 rounded-full border border-gray-600/50">
                    <Code className="w-3 h-3 text-blue-400 mr-1" />
                    <span className="text-gray-300">React + TypeScript</span>
                  </div>
                  <div className="flex items-center px-3 py-1 bg-gray-700/50 rounded-full border border-gray-600/50">
                    <Zap className="w-3 h-3 text-yellow-400 mr-1" />
                    <span className="text-gray-300">Powered by Vite</span>
                  </div>
                </div>

                {/* Version */}
                <div className="text-xs text-gray-500 font-mono">
                  v2024.1.0
                </div>
              </div>

              {/* Console Output */}
              <div className="mt-4 p-3 bg-gray-900/50 rounded-lg border border-gray-700/50">
                <div className="text-green-400 text-xs mb-1">// Console output:</div>
                <div className="text-green-300 text-xs">
                  ✅ Portfolio loaded successfully | Ready for collaboration
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;