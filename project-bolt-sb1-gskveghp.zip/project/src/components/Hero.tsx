import React, { useState, useEffect } from 'react';
import { Terminal, Code, Coffee, ArrowDown, Play, Zap, Download, MessageCircle, Sparkles, CheckCircle, Rocket, Brain, Heart, GitBranch, Database, Server, Monitor, Cpu } from 'lucide-react';
import { personalInfo } from '../data/portfolioData';

const Hero: React.FC = () => {
  const [currentCode, setCurrentCode] = useState(0);
  const [typedText, setTypedText] = useState('');
  const [showCursor, setShowCursor] = useState(true);
  const [showOutput, setShowOutput] = useState(false);
  const [systemStatus, setSystemStatus] = useState('initializing');

  const codeSnippets = [
    { 
      code: '#!/bin/bash',
      comment: '// Initializing developer environment'
    },
    { 
      code: 'class SoftwareEngineer {',
      comment: '// Defining engineer profile'
    },
    { 
      code: '  constructor() {',
      comment: '// Setting up properties'
    },
    { 
      code: '    this.name = "MD Masud Sikdar";',
      comment: '// Full Stack Software Engineer'
    },
    { 
      code: '    this.experience = "5+ years";',
      comment: '// Professional development experience'
    },
    { 
      code: '    this.stack = ["React", "Node.js", "TypeScript"];',
      comment: '// Core technology stack'
    },
    { 
      code: '    this.passion = "Building scalable systems";',
      comment: '// What drives innovation'
    },
    { 
      code: '    this.status = "available_for_hire";',
      comment: '// Current availability status'
    },
    { 
      code: '  }',
      comment: '// Constructor complete'
    },
    { 
      code: '}',
      comment: '// Class definition complete'
    },
    { 
      code: '',
      comment: '// Instantiating engineer...'
    },
    { 
      code: 'const engineer = new SoftwareEngineer();',
      comment: '// Ready to build amazing software!'
    }
  ];

  const systemMetrics = [
    { icon: CheckCircle, text: '25+ Projects Deployed', color: 'text-green-400', metric: 'projects.length' },
    { icon: Database, text: '15+ Databases Designed', color: 'text-blue-400', metric: 'databases.count' },
    { icon: Server, text: '99.9% Uptime Achieved', color: 'text-purple-400', metric: 'uptime.percentage' },
    { icon: Cpu, text: '5+ Years Experience', color: 'text-orange-400', metric: 'experience.years' }
  ];

  const techBadges = [
    { icon: Brain, text: 'Algorithm Designer', color: 'from-purple-500 to-pink-500', code: 'algorithms.optimize()' },
    { icon: Rocket, text: 'System Architect', color: 'from-blue-500 to-cyan-500', code: 'systems.scale()' },
    { icon: Heart, text: 'Code Craftsman', color: 'from-red-500 to-orange-500', code: 'code.craft()' }
  ];

  useEffect(() => {
    // System initialization sequence
    setTimeout(() => setSystemStatus('loading'), 500);
    setTimeout(() => setSystemStatus('ready'), 1500);

    if (currentCode < codeSnippets.length) {
      const currentSnippet = codeSnippets[currentCode];
      let index = 0;
      
      const typeInterval = setInterval(() => {
        if (index < currentSnippet.code.length) {
          setTypedText(currentSnippet.code.slice(0, index + 1));
          index++;
        } else {
          clearInterval(typeInterval);
          setTimeout(() => {
            if (currentCode < codeSnippets.length - 1) {
              setCurrentCode(prev => prev + 1);
              setTypedText('');
            } else {
              setShowOutput(true);
            }
          }, 800);
        }
      }, 40);

      return () => clearInterval(typeInterval);
    }
  }, [currentCode]);

  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 500);
    return () => clearInterval(cursorInterval);
  }, []);

  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  const downloadResume = () => {
    console.log('Downloading resume...');
  };

  return (
    <section id="home" className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black text-white relative overflow-hidden">
      {/* Matrix-style Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%2210%22 y=%2220%22 font-family=%22monospace%22 font-size=%226%22%3E01%3C/text%3E%3Ctext x=%2230%22 y=%2240%22 font-family=%22monospace%22 font-size=%226%22%3E10%3C/text%3E%3Ctext x=%2245%22 y=%2215%22 font-family=%22monospace%22 font-size=%226%22%3E11%3C/text%3E%3Ctext x=%225%22 y=%2250%22 font-family=%22monospace%22 font-size=%226%22%3E00%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat animate-pulse"></div>
      </div>

      {/* Floating Code Elements */}
      <div className="absolute top-20 left-10 text-green-400/20 font-mono text-2xl animate-float">{'class Engineer {}'}</div>
      <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-xl animate-bounce">{'git push origin main'}</div>
      <div className="absolute bottom-40 left-20 text-purple-400/20 font-mono text-lg animate-pulse">{'npm run build'}</div>
      <div className="absolute top-60 right-10 text-cyan-400/20 font-mono text-base animate-float">{'docker compose up'}</div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="flex items-center justify-center min-h-screen">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
            
            {/* Left Column - Enhanced Software Engineer Content */}
            <div className="text-center lg:text-left space-y-8">
              {/* System Status Badge */}
              <div className="inline-flex items-center px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full backdrop-blur-sm">
                <div className={`w-2 h-2 rounded-full mr-3 ${
                  systemStatus === 'ready' ? 'bg-green-400 animate-pulse' : 
                  systemStatus === 'loading' ? 'bg-yellow-400 animate-spin' : 
                  'bg-gray-400'
                }`}></div>
                <Terminal className="w-4 h-4 text-green-400 mr-2" />
                <span className="text-green-300 text-sm font-mono">
                  {systemStatus === 'ready' ? 'System ready • Available for hire' : 
                   systemStatus === 'loading' ? 'Loading profile...' : 
                   'Initializing...'}
                </span>
                <Sparkles className="w-4 h-4 ml-2 text-green-400" />
              </div>

              {/* Main Heading - Software Engineer Style */}
              <div>
                <div className="text-sm font-mono text-gray-400 mb-2">// Software Engineer Profile</div>
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight">
                  <span className="text-white/90 font-mono">Hello,</span>
                  <br />
                  <span className="text-gray-400 font-mono text-2xl md:text-3xl">I'm</span>
                  <br />
                  <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent font-mono">
                    Masud Sikdar
                  </span>
                </h1>
                <div className="text-2xl md:text-3xl font-semibold text-gray-300 mb-4 font-mono">
                  <span className="text-blue-400">class</span> <span className="text-yellow-300">SoftwareEngineer</span> <span className="text-gray-400">{'{'}</span>
                </div>
                <p className="text-lg text-gray-400 leading-relaxed max-w-lg mx-auto lg:mx-0 font-mono">
                  <span className="text-gray-500">// </span>{personalInfo.tagline}
                </p>
              </div>

              {/* Engineering Specializations */}
              <div className="flex flex-wrap justify-center lg:justify-start gap-3">
                {techBadges.map((badge, index) => (
                  <div key={index} className={`group relative px-4 py-2 bg-gradient-to-r ${badge.color} rounded-lg text-white text-sm font-mono hover:scale-105 transition-all duration-300 cursor-pointer border border-white/20`}>
                    <div className="flex items-center">
                      <badge.icon className="w-4 h-4 mr-2" />
                      {badge.text}
                    </div>
                    <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                      <div className="bg-gray-900 text-green-400 px-2 py-1 rounded text-xs font-mono whitespace-nowrap border border-gray-700">
                        {badge.code}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* System Metrics */}
              <div className="grid grid-cols-2 gap-3">
                {systemMetrics.map((metric, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm bg-gray-800/30 rounded-lg p-3 backdrop-blur-sm border border-gray-700/50 hover:border-gray-600/50 transition-colors">
                    <metric.icon className={`w-4 h-4 ${metric.color}`} />
                    <div>
                      <div className="text-gray-300 font-mono text-xs">{metric.text}</div>
                      <div className="text-gray-500 font-mono text-xs">{metric.metric}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Buttons - Software Engineer Style */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <button
                  onClick={scrollToProjects}
                  className="group relative inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-mono rounded-xl transition-all duration-300 hover:scale-105 shadow-lg overflow-hidden border border-green-400/30"
                >
                  {/* Animated Background */}
                  <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-blue-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Sliding Effect */}
                  <div className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  
                  {/* Content */}
                  <div className="relative flex items-center">
                    <Terminal className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                    <span>./explore --projects</span>
                    <div className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <span className="text-xs">→</span>
                    </div>
                  </div>
                </button>
                
                <button 
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="group inline-flex items-center justify-center px-8 py-4 bg-gray-800/50 hover:bg-gray-700/50 text-white font-mono rounded-xl transition-all duration-300 border border-gray-600/50 hover:border-gray-500/50 backdrop-blur-sm"
                >
                  <MessageCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  connect()
                </button>
                
                <button
                  onClick={downloadResume}
                  className="group inline-flex items-center justify-center px-8 py-4 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 font-mono rounded-xl transition-all duration-300 border border-purple-500/50 hover:border-purple-400/50 backdrop-blur-sm"
                  title="Download Resume"
                >
                  <Download className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  resume.pdf
                </button>
              </div>
            </div>

            {/* Right Column - Advanced Terminal IDE */}
            <div className="relative">
              {/* IDE Window */}
              <div className="bg-gray-900/95 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
                {/* IDE Header */}
                <div className="flex items-center justify-between px-6 py-4 bg-gray-900/80 border-b border-gray-700/50">
                  <div className="flex items-center space-x-3">
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full hover:bg-red-400 transition-colors cursor-pointer"></div>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full hover:bg-yellow-400 transition-colors cursor-pointer"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full hover:bg-green-400 transition-colors cursor-pointer"></div>
                    </div>
                    <Terminal className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-400 text-sm font-mono">SoftwareEngineer.js</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <GitBranch className="w-4 h-4 text-green-400" />
                      <span className="text-xs text-gray-400 font-mono">main</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-yellow-400" />
                      <span className="text-xs text-gray-400">Live Coding</span>
                    </div>
                  </div>
                </div>
                
                {/* Line Numbers & Content */}
                <div className="flex">
                  {/* Line Numbers */}
                  <div className="bg-gray-800/50 px-4 py-6 border-r border-gray-700/50">
                    <div className="font-mono text-xs text-gray-500 space-y-2">
                      {Array.from({ length: Math.max(15, currentCode + 5) }, (_, i) => (
                        <div key={i} className={`text-right ${i <= currentCode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {String(i + 1).padStart(2, '0')}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Code Content */}
                  <div className="flex-1 p-6 font-mono text-sm min-h-[450px]">
                    {/* Previous Lines */}
                    {codeSnippets.slice(0, currentCode).map((snippet, index) => (
                      <div key={index} className="mb-2">
                        <div className="text-gray-500 text-xs mb-1">{snippet.comment}</div>
                        <div className="flex items-center">
                          <span className={`${
                            snippet.code.includes('class') ? 'text-blue-400' :
                            snippet.code.includes('constructor') ? 'text-purple-400' :
                            snippet.code.includes('this.') ? 'text-green-400' :
                            snippet.code.includes('const') ? 'text-yellow-400' :
                            snippet.code.includes('#!/bin/bash') ? 'text-red-400' :
                            'text-gray-300'
                          }`}>
                            {snippet.code}
                          </span>
                        </div>
                      </div>
                    ))}
                    
                    {/* Current Typing Line */}
                    {currentCode < codeSnippets.length && (
                      <div className="mb-2">
                        <div className="text-gray-500 text-xs mb-1">{codeSnippets[currentCode].comment}</div>
                        <div className="flex items-center">
                          <span className={`${
                            typedText.includes('class') ? 'text-blue-400' :
                            typedText.includes('constructor') ? 'text-purple-400' :
                            typedText.includes('this.') ? 'text-green-400' :
                            typedText.includes('const') ? 'text-yellow-400' :
                            typedText.includes('#!/bin/bash') ? 'text-red-400' :
                            'text-gray-300'
                          }`}>
                            {typedText}
                          </span>
                          <span className={`text-green-400 ml-1 ${showCursor ? 'opacity-100' : 'opacity-0'}`}>|</span>
                        </div>
                      </div>
                    )}

                    {/* Output Section */}
                    {showOutput && (
                      <div className="mt-6 p-4 bg-green-900/20 rounded-lg border border-green-500/20">
                        <div className="text-green-400 text-xs mb-2">// Console Output:</div>
                        <div className="text-green-300 space-y-1 text-xs">
                          <div>✅ SoftwareEngineer instance created successfully!</div>
                          <div>🚀 All systems operational and ready for development</div>
                          <div>💼 Status: Available for new opportunities</div>
                          <div>⚡ Performance: Optimized for scalable solutions</div>
                          <div className="text-yellow-300 mt-2">→ Ready to architect your next big project!</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Floating Decorations */}
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center animate-pulse border border-blue-500/20">
                <Code className="w-8 h-8 text-blue-400" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center animate-bounce border border-green-500/20">
                <span className="text-green-400 font-mono text-lg">{ }</span>
              </div>
              <div className="absolute top-1/2 -right-6 w-8 h-8 bg-purple-500/10 rounded-full flex items-center justify-center animate-pulse border border-purple-500/20">
                <Monitor className="w-4 h-4 text-purple-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator - Software Engineer Style */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <button
            onClick={scrollToProjects}
            className="flex flex-col items-center text-gray-400 hover:text-green-400 transition-colors group animate-bounce"
          >
            <span className="text-sm mb-2 group-hover:text-green-400 transition-colors font-mono">./explore --down</span>
            <ArrowDown className="w-5 h-5 group-hover:text-green-400 transition-colors" />
          </button>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default Hero;