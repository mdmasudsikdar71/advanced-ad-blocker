import React, { useState } from 'react';
import { 
  Code, Database, Server, Wrench, Globe, Smartphone, Cloud, Shield, Zap, Star, TrendingUp, Terminal, GitBranch,
  // Frontend Icons
  Palette, Layout, Layers, Sparkles, Eye, Brush,
  // Backend Icons
  Cpu, Cog, Link, Box, FileCode,
  // Database Icons
  HardDrive, Archive, BarChart3, Table, Folder, Lock,
  // Mobile Icons
  Tablet, Wifi, Battery,
  // Cloud Icons
  CloudLightning, Settings, Gauge, Workflow,
  // Security Icons
  Bug, TestTube, CheckCircle, AlertTriangle, Key,
  // Tools Icons
  Hammer, Scissors, Paintbrush, Compass
} from 'lucide-react';
import { skills } from '../data/portfolioData';

const Skills: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('frontend');
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  // Skill-specific icons mapping
  const getSkillIcon = (skillName: string, category: string) => {
    const skillIcons: Record<string, any> = {
      // Frontend
      'React': Layers,
      'TypeScript': Code,
      'JavaScript (ES6+)': Terminal,
      'Next.js': Sparkles,
      'Vue.js': Eye,
      'Tailwind CSS': Palette,
      'Sass/SCSS': Brush,
      'HTML5 & CSS3': Layout,
      'Responsive Design': Smartphone,
      'Progressive Web Apps': Globe,
      
      // Backend
      'Node.js': Server,
      'Express.js': Link,
      'Python': FileCode,
      'Django': Box,
      'PHP': Cpu,
      'RESTful APIs': Cog,
      'GraphQL': BarChart3,
      'Microservices': Workflow,
      
      // Database
      'PostgreSQL': Database,
      'MongoDB': HardDrive,
      'MySQL': Table,
      'Redis': Archive,
      'Prisma ORM': Folder,
      'Database Design': Lock,
      
      // Mobile
      'React Native': Tablet,
      'Flutter': Wifi,
      'Mobile-First Design': Battery,
      
      // Cloud
      'AWS': Cloud,
      'Docker': Box,
      'Kubernetes': CloudLightning,
      'CI/CD Pipelines': GitBranch,
      'Vercel': Gauge,
      'Netlify': Settings,
      
      // Security
      'Jest': TestTube,
      'Cypress': Bug,
      'Unit Testing': CheckCircle,
      'Integration Testing': AlertTriangle,
      'Security Best Practices': Key,
      
      // Tools
      'Git & GitHub': GitBranch,
      'VS Code': Code,
      'Figma': Paintbrush,
      'Postman': Link,
      'Webpack': Box,
      'Vite': Zap,
      'ESLint & Prettier': Scissors
    };

    return skillIcons[skillName] || Code;
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'frontend': return Globe;
      case 'backend': return Server;
      case 'database': return Database;
      case 'mobile': return Smartphone;
      case 'cloud': return Cloud;
      case 'security': return Shield;
      case 'tools': return Wrench;
      default: return Code;
    }
  };

  const getCategoryTitle = (category: string) => {
    switch (category) {
      case 'frontend': return 'Frontend Development';
      case 'backend': return 'Backend Development';
      case 'database': return 'Database & Storage';
      case 'mobile': return 'Mobile Development';
      case 'cloud': return 'Cloud & DevOps';
      case 'security': return 'Testing & Security';
      case 'tools': return 'Development Tools';
      default: return 'Other Skills';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'frontend': return { primary: 'from-blue-500 to-cyan-500', accent: 'text-blue-400', border: 'border-blue-400/30' };
      case 'backend': return { primary: 'from-green-500 to-emerald-500', accent: 'text-green-400', border: 'border-green-400/30' };
      case 'database': return { primary: 'from-purple-500 to-violet-500', accent: 'text-purple-400', border: 'border-purple-400/30' };
      case 'mobile': return { primary: 'from-pink-500 to-rose-500', accent: 'text-pink-400', border: 'border-pink-400/30' };
      case 'cloud': return { primary: 'from-orange-500 to-amber-500', accent: 'text-orange-400', border: 'border-orange-400/30' };
      case 'security': return { primary: 'from-red-500 to-pink-500', accent: 'text-red-400', border: 'border-red-400/30' };
      case 'tools': return { primary: 'from-gray-500 to-slate-500', accent: 'text-gray-400', border: 'border-gray-400/30' };
      default: return { primary: 'from-teal-500 to-blue-500', accent: 'text-teal-400', border: 'border-teal-400/30' };
    }
  };

  const getCategoryCode = (category: string) => {
    switch (category) {
      case 'frontend': return 'frontend: {}';
      case 'backend': return 'backend: []';
      case 'database': return 'database: new Map()';
      case 'mobile': return 'mobile: () => {}';
      case 'cloud': return 'cloud: async/await';
      case 'security': return 'security: test()';
      case 'tools': return 'tools: require()';
      default: return 'skills: []';
    }
  };

  const groupedSkills = skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof skills>);

  const categories = Object.keys(groupedSkills);
  const activeSkills = groupedSkills[activeCategory] || [];
  const activeColors = getCategoryColor(activeCategory);
  const ActiveIcon = getCategoryIcon(activeCategory);

  return (
    <section id="skills" className="py-16 bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 text-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%2210%22 y=%2220%22 font-family=%22monospace%22 font-size=%226%22%3Eskill%3C/text%3E%3Ctext x=%2230%22 y=%2240%22 font-family=%22monospace%22 font-size=%226%22%3Etech%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat animate-pulse"></div>
      </div>

      {/* Floating Code Elements */}
      <div className="absolute top-20 left-10 text-green-400/20 font-mono text-lg animate-float">const skills = []</div>
      <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-sm animate-bounce">import * from 'tech'</div>
      <div className="absolute bottom-40 left-20 text-purple-400/20 font-mono text-base animate-pulse">// expertise level</div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full mb-6">
            <Terminal className="w-4 h-4 text-blue-400 mr-2" />
            <span className="text-blue-300 font-mono text-sm">./skills --list</span>
            <Zap className="w-4 h-4 text-blue-400 ml-2" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white/90">Technical</span>
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-green-400 bg-clip-text text-transparent font-mono">
              {'<Skills />'}
            </span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto font-mono">
            // Comprehensive technical stack across development domains
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Category Navigation - Terminal Style */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden sticky top-8">
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
                <div className="flex items-center space-x-3">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Terminal className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 text-sm font-mono">skills.js</span>
                </div>
                <div className="flex items-center space-x-2">
                  <GitBranch className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-gray-400">main</span>
                </div>
              </div>
              
              <div className="p-6 font-mono text-sm">
                <div className="text-gray-500 text-xs mb-4">// Available skill categories</div>
                
                <div className="space-y-2">
                  {categories.map((category) => {
                    const Icon = getCategoryIcon(category);
                    const colors = getCategoryColor(category);
                    const isActive = activeCategory === category;
                    const skillCount = groupedSkills[category].length;
                    
                    return (
                      <button
                        key={category}
                        onClick={() => setActiveCategory(category)}
                        className={`w-full p-4 rounded-lg text-left transition-all duration-300 border ${
                          isActive 
                            ? `bg-gray-700/50 ${colors.border} border shadow-lg` 
                            : 'bg-gray-800/30 hover:bg-gray-700/30 border-gray-600/30 hover:border-gray-500/50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${
                              isActive ? `bg-gradient-to-r ${colors.primary} text-white` : 'bg-gray-700/50 text-gray-400'
                            }`}>
                              <Icon className="w-5 h-5" />
                            </div>
                            <div>
                              <div className={`font-semibold text-sm ${isActive ? colors.accent : 'text-gray-300'}`}>
                                {getCategoryTitle(category).split(' ')[0]}
                              </div>
                              <div className="text-xs text-gray-500 font-mono">{getCategoryCode(category)}</div>
                            </div>
                          </div>
                          
                          <div className="text-right">
                            <div className={`text-xs ${isActive ? colors.accent : 'text-gray-500'}`}>
                              {skillCount}
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Console Output */}
                <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700/50">
                  <div className="text-green-400 text-xs mb-2">// Console output:</div>
                  <div className="text-gray-300 text-xs space-y-1">
                    <div>✅ {categories.length} categories loaded</div>
                    <div>🚀 {skills.length} total skills</div>
                    <div>⚡ Expert level proficiency</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Skills Display - Code Editor Style */}
          <div className="lg:col-span-3">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
              {/* Category Header */}
              <div className={`h-24 bg-gradient-to-r ${activeColors.primary} relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-12 translate-x-12"></div>
                
                <div className="relative p-6 h-full flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mr-4">
                      <ActiveIcon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white font-mono">
                        {getCategoryTitle(activeCategory)}
                      </h3>
                      <p className="text-white/80 text-sm font-mono">{getCategoryCode(activeCategory)}</p>
                    </div>
                  </div>
                  
                  <div className="text-right text-white">
                    <div className="text-lg font-bold">{activeSkills.length}</div>
                    <div className="text-xs opacity-80">technologies</div>
                  </div>
                </div>
              </div>

              {/* Skills Grid - Code Style */}
              <div className="p-6 bg-gray-900/50">
                <div className="text-gray-500 text-xs mb-4 font-mono">// Available technologies in {activeCategory}</div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {activeSkills.map((skill, index) => {
                    const SkillIcon = getSkillIcon(skill.name, skill.category);
                    
                    return (
                      <div
                        key={skill.name}
                        className={`group relative p-4 rounded-lg border transition-all duration-300 cursor-pointer hover:scale-105 ${
                          hoveredSkill === skill.name
                            ? `bg-gray-700/50 ${activeColors.border} border shadow-lg`
                            : 'bg-gray-800/30 border-gray-600/30 hover:border-gray-500/50'
                        }`}
                        onMouseEnter={() => setHoveredSkill(skill.name)}
                        onMouseLeave={() => setHoveredSkill(null)}
                      >
                        <div className="text-center">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 transition-all duration-300 ${
                            hoveredSkill === skill.name
                              ? `bg-gradient-to-r ${activeColors.primary} text-white shadow-lg`
                              : 'bg-gray-700/50 text-gray-400 border border-gray-600/50'
                          }`}>
                            <SkillIcon className="w-6 h-6" />
                          </div>
                          <h4 className={`font-semibold text-sm font-mono transition-colors ${
                            hoveredSkill === skill.name ? activeColors.accent : 'text-gray-300'
                          }`}>
                            {skill.name}
                          </h4>
                        </div>

                        {/* Hover Effect */}
                        {hoveredSkill === skill.name && (
                          <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent via-white/5 to-transparent animate-pulse"></div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Category Stats - Code Style */}
                <div className="mt-6 p-4 bg-gray-800/50 rounded-lg border border-gray-700/50">
                  <div className="text-green-400 text-xs mb-3 font-mono">// Category statistics</div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-lg font-bold text-white font-mono">{activeSkills.length}</div>
                      <div className="text-xs text-gray-400">Technologies</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-white font-mono">
                        {activeCategory === 'frontend' ? '5+' : activeCategory === 'backend' ? '4+' : '3+'}
                      </div>
                      <div className="text-xs text-gray-400">Years Exp</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-white font-mono">Expert</div>
                      <div className="text-xs text-gray-400">Level</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Overall Stats - Terminal Style */}
        <div className="mt-12 bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
          <div className="p-6">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-white mb-2 font-mono">
                {'// Technical Overview'}
              </h3>
              <p className="text-gray-400 font-mono text-sm">Comprehensive skill set across the development stack</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-500/20 border border-blue-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-blue-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">{skills.length}</div>
                <div className="text-sm text-gray-400">Total Skills</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-green-500/20 border border-green-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">{categories.length}</div>
                <div className="text-sm text-gray-400">Categories</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-500/20 border border-purple-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-purple-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">5+</div>
                <div className="text-sm text-gray-400">Years Experience</div>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-500/20 border border-orange-500/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Code className="w-6 h-6 text-orange-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">Expert</div>
                <div className="text-sm text-gray-400">Level</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default Skills;