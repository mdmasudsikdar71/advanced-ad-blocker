import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send, MessageCircle, Calendar, Clock, CheckCircle, ArrowRight, Sparkles, User, Briefcase, DollarSign, Zap, Coffee, Heart, Terminal, GitBranch, Code, Database, Server, Monitor } from 'lucide-react';
import { contactInfo } from '../data/portfolioData';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    projectType: '',
    budget: '',
    timeline: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [activeTab, setActiveTab] = useState<'contact' | 'project'>('contact');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', subject: '', message: '', projectType: '', budget: '', timeline: '' });
    }, 3000);
  };

  const projectTypes = [
    'Web Application',
    'E-commerce Platform',
    'Mobile App',
    'API Development',
    'System Architecture',
    'Database Design',
    'DevOps Setup',
    'Technical Consultation',
    'Code Review',
    'Performance Optimization'
  ];

  const budgetRanges = [
    '$1,000 - $5,000',
    '$5,000 - $10,000',
    '$10,000 - $25,000',
    '$25,000 - $50,000',
    '$50,000+',
    'Enterprise Contract',
    'Let\'s discuss'
  ];

  const timelines = [
    '1-2 weeks',
    '1 month',
    '2-3 months',
    '3-6 months',
    '6+ months',
    'Ongoing project'
  ];

  const contactMethods = [
    { 
      icon: Mail, 
      title: 'Email Communication', 
      subtitle: 'Best for detailed technical discussions',
      value: contactInfo.email, 
      href: `mailto:${contactInfo.email}`,
      color: 'from-blue-500 to-cyan-500',
      responseTime: '< 2 hours',
      code: 'sendEmail()',
      protocol: 'SMTP'
    },
    { 
      icon: Phone, 
      title: 'Voice Call', 
      subtitle: 'Quick technical consultations',
      value: contactInfo.phone, 
      href: `tel:${contactInfo.phone}`,
      color: 'from-green-500 to-emerald-500',
      responseTime: 'Business hours',
      code: 'makeCall()',
      protocol: 'VoIP'
    },
    { 
      icon: MapPin, 
      title: 'Location', 
      subtitle: 'Remote-first, global availability',
      value: contactInfo.location,
      color: 'from-purple-500 to-violet-500',
      responseTime: '24/7 availability',
      code: 'getLocation()',
      protocol: 'GPS'
    }
  ];

  return (
    <section id="contact" className="py-16 bg-gradient-to-br from-gray-900 via-slate-900 to-black text-white relative overflow-hidden">
      {/* Matrix Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22%2300ff00%22 fill-opacity=%220.1%22%3E%3Ctext x=%2210%22 y=%2220%22 font-family=%22monospace%22 font-size=%226%22%3Eapi%3C/text%3E%3Ctext x=%2230%22 y=%2240%22 font-family=%22monospace%22 font-size=%226%22%3Epost%3C/text%3E%3Ctext x=%225%22 y=%2250%22 font-family=%22monospace%22 font-size=%226%22%3Ehttp%3C/text%3E%3C/g%3E%3C/svg%3E')] repeat animate-pulse"></div>
      </div>

      {/* Floating Code Elements */}
      <div className="absolute top-20 left-10 text-green-400/20 font-mono text-lg animate-float">const contact = new API()</div>
      <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-sm animate-bounce">await fetch('/contact')</div>
      <div className="absolute bottom-40 left-20 text-purple-400/20 font-mono text-base animate-pulse">// POST request</div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full mb-6">
            <Terminal className="w-4 h-4 text-green-400 mr-2" />
            <span className="text-green-300 font-mono text-sm">./contact --init --secure</span>
            <Sparkles className="w-4 h-4 text-green-400 ml-2" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-white/90">Let's Build</span>
            <br />
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent font-mono">
              {'<Something />'}
            </span>
            <span className="text-white/90"> Amazing</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed font-mono">
            // Ready to architect your next software solution? Let's connect!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Methods - Advanced Terminal Style */}
          <div className="space-y-6">
            {/* Contact API Endpoints */}
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
                <div className="flex items-center space-x-3">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Terminal className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 text-sm font-mono">contact-api.js</span>
                </div>
                <div className="flex items-center space-x-2">
                  <GitBranch className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-gray-400">main</span>
                </div>
              </div>

              <div className="p-6 space-y-4">
                <div className="text-gray-500 text-xs mb-4 font-mono">// Available communication endpoints</div>
                
                {contactMethods.map((method, index) => (
                  <div key={index} className="group">
                    <div className={`p-4 rounded-lg bg-gradient-to-r ${method.color} text-white hover:scale-105 transition-all duration-300 cursor-pointer shadow-lg border border-gray-600/30`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center">
                          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mr-3 border border-white/30">
                            <method.icon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="font-bold text-lg font-mono">{method.title}</h4>
                            <p className="text-white/80 text-sm">{method.subtitle}</p>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-white/70 group-hover:translate-x-1 transition-transform" />
                      </div>
                      
                      <div className="space-y-2">
                        {method.href ? (
                          <a
                            href={method.href}
                            className="block text-white font-mono hover:underline text-sm"
                          >
                            {method.value}
                          </a>
                        ) : (
                          <p className="text-white font-mono text-sm">{method.value}</p>
                        )}
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/70 font-mono">{method.code}</span>
                          <span className="text-white/70">{method.protocol}</span>
                        </div>
                        <div className="text-white/60 text-xs">Response time: {method.responseTime}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* System Status - Advanced */}
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-3 h-3 bg-green-400 rounded-full mr-3 animate-pulse"></div>
                <h4 className="text-lg font-bold text-white font-mono">system.status = 'ONLINE'</h4>
                <Coffee className="w-5 h-5 ml-2 text-green-400" />
              </div>
              <p className="text-gray-300 mb-4 font-mono text-sm">
                // All systems operational, ready for new connections
              </p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="p-3 bg-gray-700/50 rounded-lg border border-gray-600/50">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center text-gray-300 font-mono">
                      <Clock className="w-4 h-4 mr-2" />
                      responseTime
                    </span>
                    <span className="font-semibold text-green-400 font-mono">'&lt; 2h'</span>
                  </div>
                </div>
                <div className="p-3 bg-gray-700/50 rounded-lg border border-gray-600/50">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center text-gray-300 font-mono">
                      <Calendar className="w-4 h-4 mr-2" />
                      availability
                    </span>
                    <span className="font-semibold text-green-400 font-mono">'24/7'</span>
                  </div>
                </div>
                <div className="p-3 bg-gray-700/50 rounded-lg border border-gray-600/50">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center text-gray-300 font-mono">
                      <Server className="w-4 h-4 mr-2" />
                      uptime
                    </span>
                    <span className="font-semibold text-green-400 font-mono">'99.9%'</span>
                  </div>
                </div>
                <div className="p-3 bg-gray-700/50 rounded-lg border border-gray-600/50">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center text-gray-300 font-mono">
                      <Database className="w-4 h-4 mr-2" />
                      capacity
                    </span>
                    <span className="font-semibold text-green-400 font-mono">'available'</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Why Choose Me - Software Engineer Style */}
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl p-6">
              <h4 className="text-lg font-bold text-white mb-4 flex items-center font-mono">
                <Heart className="w-5 h-5 mr-2 text-red-400" />
                whyChooseMe()
              </h4>
              <div className="space-y-3 font-mono text-sm">
                <div className="flex items-center text-gray-300">
                  <Zap className="w-4 h-4 mr-3 text-yellow-400" />
                  <span>experience: '5+ years in software engineering'</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <CheckCircle className="w-4 h-4 mr-3 text-green-400" />
                  <span>deliveryRate: '100% on-time delivery'</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Sparkles className="w-4 h-4 mr-3 text-purple-400" />
                  <span>techStack: 'cutting-edge technologies'</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Monitor className="w-4 h-4 mr-3 text-blue-400" />
                  <span>architecture: 'scalable & maintainable'</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form - Advanced IDE Style */}
          <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
            {/* IDE Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-gray-900/50 border-b border-gray-700/50">
              <div className="flex items-center space-x-3">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <Terminal className="w-4 h-4 text-gray-400" />
                <span className="text-gray-400 text-sm font-mono">ContactForm.tsx</span>
              </div>
              <div className="flex items-center space-x-2">
                <Code className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-gray-400">TypeScript</span>
              </div>
            </div>

            <div className="p-6">
              {/* Tab Navigation - Code Style */}
              <div className="flex space-x-1 mb-6 bg-gray-900/50 rounded-lg p-1 border border-gray-700/50">
                <button
                  onClick={() => setActiveTab('contact')}
                  className={`flex-1 py-3 px-4 rounded-md text-sm font-mono transition-all duration-200 flex items-center justify-center ${
                    activeTab === 'contact'
                      ? 'bg-gray-700/50 text-green-400 border border-green-400/30'
                      : 'text-gray-400 hover:text-gray-300'
                  }`}
                >
                  <User className="w-4 h-4 mr-2" />
                  generalContact()
                </button>
                <button
                  onClick={() => setActiveTab('project')}
                  className={`flex-1 py-3 px-4 rounded-md text-sm font-mono transition-all duration-200 flex items-center justify-center ${
                    activeTab === 'project'
                      ? 'bg-gray-700/50 text-green-400 border border-green-400/30'
                      : 'text-gray-400 hover:text-gray-300'
                  }`}
                >
                  <Briefcase className="w-4 h-4 mr-2" />
                  projectRequest()
                </button>
              </div>

              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-500/20 border border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2 font-mono">Message Sent!</h3>
                  <p className="text-gray-400 font-mono text-sm">// Thank you for reaching out. Processing request...</p>
                  <div className="mt-4 p-3 bg-green-900/20 rounded-lg border border-green-500/20">
                    <div className="text-green-400 text-xs mb-1 font-mono">// Console output:</div>
                    <div className="text-green-300 text-xs font-mono">
                      ✅ POST /contact → 200 OK | Response incoming!
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="text-gray-500 text-xs mb-4 font-mono">// Fill out the contact form below</div>
                  
                  {/* Basic Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-mono text-gray-300 mb-2">
                        name: string <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                        placeholder="'Your full name'"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-mono text-gray-300 mb-2">
                        email: string <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                        placeholder="'your.email@domain.com'"
                      />
                    </div>
                  </div>

                  {/* Project-specific fields */}
                  {activeTab === 'project' && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-900/50 rounded-lg border border-gray-700/50">
                      <div>
                        <label htmlFor="projectType" className="block text-sm font-mono text-gray-300 mb-2">
                          <Briefcase className="w-4 h-4 inline mr-1" />
                          projectType
                        </label>
                        <select
                          id="projectType"
                          name="projectType"
                          value={formData.projectType}
                          onChange={handleChange}
                          className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                        >
                          <option value="">Select type</option>
                          {projectTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label htmlFor="budget" className="block text-sm font-mono text-gray-300 mb-2">
                          <DollarSign className="w-4 h-4 inline mr-1" />
                          budget
                        </label>
                        <select
                          id="budget"
                          name="budget"
                          value={formData.budget}
                          onChange={handleChange}
                          className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                        >
                          <option value="">Select budget</option>
                          {budgetRanges.map((range) => (
                            <option key={range} value={range}>{range}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label htmlFor="timeline" className="block text-sm font-mono text-gray-300 mb-2">
                          <Calendar className="w-4 h-4 inline mr-1" />
                          timeline
                        </label>
                        <select
                          id="timeline"
                          name="timeline"
                          value={formData.timeline}
                          onChange={handleChange}
                          className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                        >
                          <option value="">Select timeline</option>
                          {timelines.map((time) => (
                            <option key={time} value={time}>{time}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  <div>
                    <label htmlFor="subject" className="block text-sm font-mono text-gray-300 mb-2">
                      subject: string <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 text-white font-mono"
                      placeholder={activeTab === 'project' ? "'Software project requirements'" : "'What would you like to discuss?'"}
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-mono text-gray-300 mb-2">
                      message: string <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={6}
                      className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all duration-200 resize-none text-white font-mono"
                      placeholder={
                        activeTab === 'project' 
                          ? "'Describe your software requirements, technical specifications, and project goals...'"
                          : "'Your message here...'"
                      }
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 text-white font-mono py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center group border border-green-400/30"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        await sendMessage()...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform" />
                        POST /contact
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default Contact;